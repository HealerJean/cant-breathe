package chapter5.parallel_compute;

/**
 * Created by 13 on 2017/5/9.
 */
public class Msg {

    public double i;
    public double j;
    public String orgStr = null;

}
